<h2 align="center"> <img src="https://raw.githubusercontent.com/DARK-H4CKER01/CODEX/refs/heads/main/files/Dx-codex.jpg" width="470" /> </h2>

<p align="center">

<p align="center"><b>Codex Banner</b <code></code></p>



## INSTALL WITH TERMUX :

```
apt update
```
```
apt upgrade -y
```
```
pkg install git -y
```
```
git clone https://github.com/DARK-H4CKER01/CODEX.git
```
```
cd CODEX/
```
```
chmod +x *
```
```
bash install.sh
```

### RUN :

```
exit
```

### AT ONCE :

```
apt update && apt upgrade -y ; pkg install git -y ; git clone https://github.com/DARK-H4CKER01/CODEX.git ; cd CODEX/ ; chmod +x * ; bash install.sh
```

<details id="missing-code-coverage">
  <summary>Use Tool</summary>

##### How to use CODEX Banner tools

```

```

</details>
